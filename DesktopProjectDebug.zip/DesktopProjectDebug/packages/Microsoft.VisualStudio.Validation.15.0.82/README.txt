﻿Code snippets are available to make adding input validation even easier.

Run the tools\install-snippets.cmd script from the NuGet package
to add the snippets to your Visual Studio installation.