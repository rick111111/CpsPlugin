//
// editids.h
// NOTE this file is superseded and defines moved to vsshlids.h
//
#ifndef _EDITIDS_H_
#define _EDITIDS_H_


#include "virtkeys.h"
#include "stdidcmd.h"
#include "vsshlids.h"
#include "sharedids.h"
#endif //_EDITIDS_H_